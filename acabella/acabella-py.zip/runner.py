"""
Bridge between the ACABELLA web page and the ACABELLA / ISABELLA Python code.

The page runs this module inside Pyodide (Python in the browser). Every
function takes a JSON string and returns a JSON string, so the JavaScript
side never has to touch Python objects. The same module also runs under
normal CPython, which is how build.py --check tests it.
"""

import contextlib
import io
import json
import re
import traceback

from sympy import latex

from acabella.core.common.parse_config import ParseConfig
from acabella.core.cryptanalysis.analysis import AnalysisWithCorruption
from acabella.core.extensions.isabella import analyze as isabella_analyze
from acabella.core.extensions.isabella import parse as isabella_parse

SECTION_TITLES = {
    "security": "Security analysis",
    "master_key": "Master-key attack",
    "decryption": "Decryption attack",
}
PLACEHOLDERS = {"sec_placeholder", "mk_placeholder", "da_placeholder"}
IDENT = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]*\b")


def _clean(lines):
    text = "\n".join(str(l) for l in lines if l not in PLACEHOLDERS)
    return text.strip("\n")


def _run_section(name, cfg_dict):
    cfg = ParseConfig()
    cfg.json_parsed = cfg_dict
    analysis = AnalysisWithCorruption()

    if name == "security":
        params = cfg.generate_security_analysis_params()
        if params is None:
            raise ValueError("Some fields could not be read; check the encodings and the variable lists.")
        analysis.init(None, None, None, None, params)
    elif name == "master_key":
        params, corr = cfg.generate_master_key_params()
        if params is None:
            raise ValueError("Some fields could not be read; check the encodings and the variable lists.")
        analysis.init(params, None, corr, None, None)
    elif name == "decryption":
        params, corr = cfg.generate_dec_key_params()
        if params is None:
            raise ValueError("Some fields could not be read; check the encodings and the variable lists.")
        analysis.init(None, params, None, corr, None)
    else:
        raise ValueError(f"Unknown analysis type {name!r}.")

    log = io.StringIO()
    with contextlib.redirect_stdout(log):
        analysis.run()
        lines, proof, proof_header = analysis.show_solution()
    return {
        "output": _clean(lines),
        "proof": proof,
        "proof_header": (proof_header or "").strip("\n") or None,
    }


def run_acabella(payload_json: str) -> str:
    """payload: {"scheme_id": str, "sections": {name: flat ACABELLA JSON}}"""
    payload = json.loads(payload_json)
    results = []
    for name in ("security", "master_key", "decryption"):
        cfg = payload.get("sections", {}).get(name)
        if cfg is None:
            continue
        cfg = dict(cfg, scheme_id=payload.get("scheme_id", ""), analysis=name)
        entry = {"name": name, "title": SECTION_TITLES[name]}
        try:
            entry.update(_run_section(name, cfg))
        except Exception as exc:  # report, don't crash the page
            entry["error"] = f"{type(exc).__name__}: {exc}"
            entry["trace"] = traceback.format_exc(limit=4)
        results.append(entry)
    return json.dumps({"results": results})


def _symbols_in(exprs):
    return set(IDENT.findall(" ".join(exprs)))


def _sort_key(name):
    # alpha1 < alpha2 < alpha10, b1 < b110, ...
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", name)]


def run_isabella(payload_json: str) -> str:
    """payload: {"k", "c", "mpk", "key", "known_vars", "corruptable_vars"}

    Older example files list unknown_vars instead of known_vars; in that
    case every other symbol in the encodings is treated as known.
    """
    p = json.loads(payload_json)
    k, c, mpk = list(p.get("k", [])), list(p.get("c", [])), list(p.get("mpk", []))
    key = str(p.get("key", ""))
    corruptable = list(p.get("corruptable_vars", []))
    known = p.get("known_vars")
    note = None
    if known is None:
        unknown = set(p.get("unknown_vars", []))
        known = sorted(_symbols_in(k + c + [key]) - unknown - set(mpk))
        note = "known_vars was derived as all symbols not listed in unknown_vars: " + ", ".join(known)

    log = io.StringIO()
    try:
        with contextlib.redirect_stdout(log):
            parsed = isabella_parse(k, c, mpk, known, corruptable, key)
            vectors = isabella_analyze(*parsed)
    except Exception as exc:
        return json.dumps({
            "error": f"{type(exc).__name__}: {exc}",
            "trace": traceback.format_exc(limit=4),
            "note": note,
        })

    out = [
        {"var": str(var), "var_latex": latex(var), "latex": latex(val), "text": str(val)}
        for var, val in sorted(vectors.items(), key=lambda kv: _sort_key(str(kv[0])))
    ]
    return json.dumps({
        "vectors": out,
        "json": {str(var): str(val) for var, val in vectors.items()},
        "note": note,
    })
